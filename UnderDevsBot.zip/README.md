# UnderDevs Bot (Render-ready)

This is a production-ready Discord bot built with **discord.js**. It includes:
- Job posting + apply system (buttons + DMs)
- Application review (accept/reject) with DM notifications
- Moderation (kick/ban)
- Announcements, verify button, and basic setup commands
- SQLite database (no external setup required)

## Quick start (locally)
1. Copy repository.
2. Create `.env` with your token and optional settings:
```
TOKEN=YOUR_DISCORD_BOT_TOKEN
CLIENT_ID=YOUR_BOT_CLIENT_ID   # optional, for deploying slash commands
GUILD_ID=YOUR_GUILD_ID         # optional, for guild-scoped commands during testing
COLOR_PRIMARY=#007BFF
```
3. Install deps:
```
npm install
```
4. (Optional) Deploy commands to a guild for quick testing:
```
npm run deploy-commands
```
5. Run:
```
npm start
```

## Render
- Create a **Web Service** on Render, connect your GitHub repo and set:
  - Runtime: Node
  - Build command: `npm install`
  - Start command: `npm start`
- Add environment variable `TOKEN` with your bot token.
- (Optional) Add `CLIENT_ID` and `GUILD_ID` to deploy commands automatically.

---
Files included: `index.js`, `deploy-commands.js`, `commands/`, `events/`, `database/db.js`, `.env.example`
